# mchacks-2020
This is the github project for mcHacks 2020

Team members are Zhe, James, Darien, Vanna, Vanessa
Hello hello hi 
this is vanna

to commit a local change to github repo
first pull
then edit
then save, and then open source control, press "+" to stage changes
then press checkmark
then push to the directory on github
inform everyone that a change has been pushed so they can pull